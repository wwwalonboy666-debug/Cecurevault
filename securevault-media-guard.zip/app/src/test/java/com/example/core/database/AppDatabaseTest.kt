package com.example.core.database

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.database.dao.MediaSourceDao
import com.example.core.database.dao.ProtectedMediaDao
import com.example.core.database.dao.ProtectionLogDao
import com.example.core.database.dao.ProtectionTaskQueueDao
import com.example.core.database.entity.LogEventType
import com.example.core.database.entity.MediaSourceEntity
import com.example.core.database.entity.MediaType
import com.example.core.database.entity.OriginalStatus
import com.example.core.database.entity.ProtectedMediaEntity
import com.example.core.database.entity.ProtectionLogEntity
import com.example.core.database.entity.ProtectionState
import com.example.core.database.entity.ProtectionTaskEntity
import com.example.core.database.entity.RetentionPolicy
import com.example.core.database.entity.TaskState
import com.example.core.database.entity.VerificationState
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AppDatabaseTest {

    private lateinit var database: AppDatabase
    private lateinit var protectedMediaDao: ProtectedMediaDao
    private lateinit var mediaSourceDao: MediaSourceDao
    private lateinit var protectionLogDao: ProtectionLogDao
    private lateinit var taskQueueDao: ProtectionTaskQueueDao

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.createInMemory(context)
        protectedMediaDao = database.protectedMediaDao()
        mediaSourceDao = database.mediaSourceDao()
        protectionLogDao = database.protectionLogDao()
        taskQueueDao = database.protectionTaskQueueDao()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `database initialization creates valid instance`() {
        assertNotNull(database)
        assertNotNull(protectedMediaDao)
        assertNotNull(mediaSourceDao)
        assertNotNull(protectionLogDao)
        assertNotNull(taskQueueDao)
    }

    @Test
    fun `protected media insertion and read with default retention`() = runBlocking {
        val now = 1700000000000L
        val entity = ProtectedMediaEntity(
            originalMediaStoreId = 101L,
            originalDocumentId = null,
            originalRelativePath = "DCIM/Camera/",
            originalVolumeName = "external_primary",
            originalFileName = "IMG_2026.jpg",
            vaultRelativePath = "vault/uuid-101.vault",
            mediaType = MediaType.PHOTO,
            mimeType = "image/jpeg",
            sizeBytes = 4096000L,
            headerChecksum = "crc32_abc123",
            fullSha256 = null,
            dateTaken = now - 10000,
            dateModified = now - 5000,
            protectedAt = now
            // retentionDays defaults to 90
        )

        val id = protectedMediaDao.insert(entity)
        assertTrue(id > 0)

        val retrieved = protectedMediaDao.getById(id)
        assertNotNull(retrieved)
        assertEquals("IMG_2026.jpg", retrieved?.originalFileName)
        assertEquals(RetentionPolicy.DEFAULT_RETENTION_DAYS, retrieved?.retentionDays)
        assertEquals(90, retrieved?.retentionDays)
        assertEquals(now + (90 * 86_400_000L), retrieved?.expiresAt)
        assertEquals(OriginalStatus.ACCESSIBLE, retrieved?.originalStatus)
        assertEquals(ProtectionState.QUEUED, retrieved?.protectionState)
        assertEquals(VerificationState.PENDING_CHECK, retrieved?.verificationState)
        assertEquals(false, retrieved?.isEncrypted)
    }

    @Test
    fun `retention policy strictly accepts only 30, 90, and 180 days`() {
        // Valid options: 30, 90, 180
        assertEquals(30, RetentionPolicy.validate(30))
        assertEquals(90, RetentionPolicy.validate(90))
        assertEquals(180, RetentionPolicy.validate(180))

        // Invalid options: 60, 0, -1, 365, etc.
        assertThrows(IllegalArgumentException::class.java) {
            RetentionPolicy.validate(60)
        }
        assertThrows(IllegalArgumentException::class.java) {
            RetentionPolicy.validate(0)
        }
        assertThrows(IllegalArgumentException::class.java) {
            RetentionPolicy.validate(-1)
        }
        assertThrows(IllegalArgumentException::class.java) {
            RetentionPolicy.validate(365)
        }

        // Entity level validation
        assertThrows(IllegalArgumentException::class.java) {
            ProtectedMediaEntity(
                originalFileName = "test.jpg",
                vaultRelativePath = "vault/test.vault",
                mediaType = MediaType.PHOTO,
                mimeType = "image/jpeg",
                sizeBytes = 1000L,
                headerChecksum = "hash1",
                dateTaken = 0L,
                dateModified = 0L,
                protectedAt = 1000L,
                retentionDays = 60 // Invalid for V1!
            )
        }
    }

    @Test
    fun `multi-factor identity queries return expected item`() = runBlocking {
        val now = 1700000000000L
        val entity = ProtectedMediaEntity(
            originalMediaStoreId = 555L,
            originalDocumentId = "doc_tree_123",
            originalRelativePath = "Pictures/Protected/",
            originalVolumeName = "external_primary",
            originalFileName = "VID_Family.mp4",
            vaultRelativePath = "vault/vid_family.vault",
            mediaType = MediaType.VIDEO,
            mimeType = "video/mp4",
            sizeBytes = 104857600L,
            headerChecksum = "header_checksum_xyz",
            fullSha256 = "full_sha_256_mock_hash",
            dateTaken = now,
            dateModified = now,
            protectedAt = now,
            retentionDays = 180,
            originalStatus = OriginalStatus.ACCESSIBLE,
            protectionState = ProtectionState.PROTECTED,
            verificationState = VerificationState.VERIFIED,
            isEncrypted = true
        )

        protectedMediaDao.insert(entity)

        // Query by MediaStore ID
        val byMediaStore = protectedMediaDao.getByOriginalMediaStoreId(555L)
        assertNotNull(byMediaStore)
        assertEquals("VID_Family.mp4", byMediaStore?.originalFileName)

        // Query by SAF Document ID
        val byDocId = protectedMediaDao.getByOriginalDocumentId("doc_tree_123")
        assertNotNull(byDocId)
        assertEquals("VID_Family.mp4", byDocId?.originalFileName)

        // Query by Header Checksum
        val byChecksum = protectedMediaDao.getByHeaderChecksum("header_checksum_xyz")
        assertEquals(1, byChecksum.size)
        assertEquals("VID_Family.mp4", byChecksum[0].originalFileName)
    }

    @Test
    fun `media source persistence and autoProtect query`() = runBlocking {
        val source1 = MediaSourceEntity(
            folderName = "Camera",
            folderUri = "content://media/external/images/media/camera",
            isSafTree = false,
            autoProtect = true,
            lastScanTimestamp = 1000L
        )
        val source2 = MediaSourceEntity(
            folderName = "Custom SD Vault",
            folderUri = "content://com.android.externalstorage.documents/tree/1234",
            isSafTree = true,
            autoProtect = false,
            lastScanTimestamp = 2000L
        )

        mediaSourceDao.insert(source1)
        mediaSourceDao.insert(source2)

        val autoSources = mediaSourceDao.getAutoProtectSources()
        assertEquals(1, autoSources.size)
        assertEquals("Camera", autoSources[0].folderName)

        val byUri = mediaSourceDao.getByUri("content://com.android.externalstorage.documents/tree/1234")
        assertNotNull(byUri)
        assertTrue(byUri!!.isSafTree)
    }

    @Test
    fun `protection task queue state transitions and retry retrieval`() = runBlocking {
        val taskPending = ProtectionTaskEntity(
            mediaUri = "content://media/external/images/1",
            attemptCount = 0,
            taskState = TaskState.PENDING
        )
        val taskFailedRetryable = ProtectionTaskEntity(
            mediaUri = "content://media/external/images/2",
            attemptCount = 1,
            nextRetryAt = 1000L,
            taskState = TaskState.FAILED_RETRYABLE
        )
        val taskCompleted = ProtectionTaskEntity(
            mediaUri = "content://media/external/images/3",
            attemptCount = 1,
            taskState = TaskState.COMPLETED
        )

        taskQueueDao.insert(taskPending)
        taskQueueDao.insert(taskFailedRetryable)
        taskQueueDao.insert(taskCompleted)

        // At currentTime = 500, only PENDING is runnable (nextRetryAt 1000 is in the future)
        val runnableAt500 = taskQueueDao.getRunnableTasks(currentTime = 500L)
        assertEquals(1, runnableAt500.size)
        assertEquals("content://media/external/images/1", runnableAt500[0].mediaUri)

        // At currentTime = 1500, both PENDING and FAILED_RETRYABLE are runnable
        val runnableAt1500 = taskQueueDao.getRunnableTasks(currentTime = 1500L)
        assertEquals(2, runnableAt1500.size)

        taskQueueDao.clearCompleted()
        val allRunnableAfterClear = taskQueueDao.getRunnableTasks(currentTime = 2000L)
        assertEquals(2, allRunnableAfterClear.size)
    }

    @Test
    fun `protection log persistence and media filtering`() = runBlocking {
        val log1 = ProtectionLogEntity(
            mediaId = 1001L,
            eventType = LogEventType.PROTECTED,
            timestamp = 1000L,
            details = "Protected photo verified with AES-GCM"
        )
        val log2 = ProtectionLogEntity(
            mediaId = 1001L,
            eventType = LogEventType.VERIFIED,
            timestamp = 2000L,
            details = "Periodic verification passed"
        )
        val log3 = ProtectionLogEntity(
            mediaId = 1002L,
            eventType = LogEventType.ORIGINAL_MISSING,
            timestamp = 3000L,
            details = "Original file missing from MediaStore"
        )

        protectionLogDao.insert(log1)
        protectionLogDao.insert(log2)
        protectionLogDao.insert(log3)

        val id = protectedMediaDao.insert(
            ProtectedMediaEntity(
                id = 1001L,
                originalFileName = "test.jpg",
                vaultRelativePath = "vault/test.vault",
                mediaType = MediaType.PHOTO,
                mimeType = "image/jpeg",
                sizeBytes = 2048L,
                headerChecksum = "chk1",
                dateTaken = 0L,
                dateModified = 0L,
                protectedAt = 500L
            )
        )
        assertTrue(id > 0)
    }
}
