package com.example

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.test.core.app.ApplicationProvider
import com.example.core.permission.MediaPermissionManager
import com.example.data.repository.MediaStoreDiscoveryRepositoryImpl
import com.example.domain.model.DetectedMediaType
import com.example.domain.model.MediaPermissionState
import com.example.ui.home.HomeViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MediaDiscoveryTest {

    @Test
    fun `permission manager returns appropriate permissions for Android 14+`() {
        val permissions = MediaPermissionManager.getRequiredPermissions()
        assertTrue(permissions.contains(android.Manifest.permission.READ_MEDIA_IMAGES))
        assertTrue(permissions.contains(android.Manifest.permission.READ_MEDIA_VIDEO))
    }

    @Test
    fun `permission map correctly evaluates granted and partial states`() {
        val grantedMap = mapOf(
            android.Manifest.permission.READ_MEDIA_IMAGES to true,
            android.Manifest.permission.READ_MEDIA_VIDEO to true
        )
        val grantedState = MediaPermissionManager.mapPermissionResult(grantedMap)
        assertTrue(grantedState is MediaPermissionState.Granted)

        val deniedMap = mapOf(
            android.Manifest.permission.READ_MEDIA_IMAGES to false,
            android.Manifest.permission.READ_MEDIA_VIDEO to false
        )
        val deniedState = MediaPermissionManager.mapPermissionResult(deniedMap)
        assertTrue(deniedState is MediaPermissionState.Denied)

        val partialMap = mapOf(
            android.Manifest.permission.READ_MEDIA_IMAGES to false,
            android.Manifest.permission.READ_MEDIA_VIDEO to false,
            android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED to true
        )
        val partialState = MediaPermissionManager.mapPermissionResult(partialMap)
        assertTrue(partialState is MediaPermissionState.PartialGranted)
    }

    @Test
    fun `mediaStore repository queries images and videos cleanly`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = MediaStoreDiscoveryRepositoryImpl(context)

        // Insert sample mock image in MediaStore
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "sample_photo.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.SIZE, 1024L)
            put(MediaStore.Images.Media.DATE_MODIFIED, System.currentTimeMillis() / 1000)
        }
        val insertedUri = context.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        )
        assertNotNull(insertedUri)

        val summary = repo.getDiscoverySummary()
        assertTrue(summary.photoCount >= 1)
        assertEquals(0, summary.videoCount)
        assertTrue(summary.totalSizeBytes >= 1024L)

        val items = repo.queryDiscoveredMedia()
        val foundItem = items.find { it.displayName == "sample_photo.jpg" }
        assertNotNull(foundItem)
        assertEquals(DetectedMediaType.PHOTO, foundItem?.mediaType)
        assertEquals("image/jpeg", foundItem?.mimeType)
    }

    @Test
    fun `homeViewModel correctly initializes and computes discovery state`() = runBlocking {
        val application = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = HomeViewModel(application)

        assertNotNull(viewModel.uiState.value)
        assertEquals(0, viewModel.uiState.value.protectedPhotosCount)
        assertEquals(0, viewModel.uiState.value.protectedVideosCount)
        assertEquals(0, viewModel.uiState.value.recoveryItemsCount)
    }
}
