package com.example.data

/**
 * Data layer package for Media Protector.
 * Houses repository implementations and background workers.
 */
object DataPackage
