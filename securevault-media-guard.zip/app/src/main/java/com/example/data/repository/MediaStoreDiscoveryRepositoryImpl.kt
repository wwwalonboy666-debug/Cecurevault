package com.example.data.repository

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.domain.model.DetectedMediaType
import com.example.domain.model.DiscoveredMediaItem
import com.example.domain.model.MediaDiscoverySummary
import com.example.domain.repository.MediaStoreDiscoveryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Concrete implementation of MediaStoreDiscoveryRepository that queries
 * Android MediaStore.Images and MediaStore.Video for metadata only.
 * Strictly local, does not calculate hashes or read full file contents.
 */
class MediaStoreDiscoveryRepositoryImpl(
    private val context: Context
) : MediaStoreDiscoveryRepository {

    override suspend fun queryDiscoveredMedia(): List<DiscoveredMediaItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<DiscoveredMediaItem>()

        try {
            // 1. Query Images
            val images = queryMediaCollection(
                collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                },
                mediaType = DetectedMediaType.PHOTO
            )
            result.addAll(images)

            // 2. Query Videos
            val videos = queryMediaCollection(
                collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                },
                mediaType = DetectedMediaType.VIDEO
            )
            result.addAll(videos)

            // Sort most recent first
            result.sortByDescending { it.dateModifiedSec }
        } catch (e: SecurityException) {
            // Permission revoked or not granted
            return@withContext emptyList()
        } catch (e: Exception) {
            return@withContext emptyList()
        }

        result
    }

    override suspend fun getDiscoverySummary(): MediaDiscoverySummary = withContext(Dispatchers.IO) {
        val items = queryDiscoveredMedia()
        var photoCount = 0
        var videoCount = 0
        var totalBytes = 0L

        for (item in items) {
            when (item.mediaType) {
                DetectedMediaType.PHOTO -> photoCount++
                DetectedMediaType.VIDEO -> videoCount++
            }
            totalBytes += item.sizeBytes
        }

        MediaDiscoverySummary(
            photoCount = photoCount,
            videoCount = videoCount,
            totalSizeBytes = totalBytes,
            recentItems = items.take(10)
        )
    }

    private fun queryMediaCollection(
        collectionUri: Uri,
        mediaType: DetectedMediaType
    ): List<DiscoveredMediaItem> {
        val items = mutableListOf<DiscoveredMediaItem>()

        val projection = mutableListOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.VOLUME_NAME)
                add(MediaStore.MediaColumns.RELATIVE_PATH)
                add(MediaStore.MediaColumns.DATE_TAKEN)
                add(MediaStore.MediaColumns.WIDTH)
                add(MediaStore.MediaColumns.HEIGHT)
            }
        }.toTypedArray()

        val selection = when (mediaType) {
            DetectedMediaType.PHOTO -> "${MediaStore.MediaColumns.MIME_TYPE} LIKE ?"
            DetectedMediaType.VIDEO -> "${MediaStore.MediaColumns.MIME_TYPE} LIKE ?"
        }
        val selectionArgs = when (mediaType) {
            DetectedMediaType.PHOTO -> arrayOf("image/%")
            DetectedMediaType.VIDEO -> arrayOf("video/%")
        }

        val sortOrder = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"

        val cursor: Cursor? = context.contentResolver.query(
            collectionUri,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )

        cursor?.use { c ->
            val idColumn = c.getColumnIndex(MediaStore.MediaColumns._ID)
            val nameColumn = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeColumn = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val sizeColumn = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            val dateModColumn = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)

            val volumeColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.VOLUME_NAME)
            } else -1

            val relativePathColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
            } else -1

            val dateTakenColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
            } else -1

            val widthColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
            } else -1

            val heightColumn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
            } else -1

            while (c.moveToNext()) {
                val id = if (idColumn != -1) c.getLong(idColumn) else continue
                val name = if (nameColumn != -1) c.getString(nameColumn) ?: "media_$id" else "media_$id"
                val mime = if (mimeColumn != -1) c.getString(mimeColumn) ?: "application/octet-stream" else "application/octet-stream"
                val size = if (sizeColumn != -1) c.getLong(sizeColumn) else 0L
                val dateModified = if (dateModColumn != -1) c.getLong(dateModColumn) else 0L

                val volume = if (volumeColumn != -1 && !c.isNull(volumeColumn)) {
                    c.getString(volumeColumn) ?: MediaStore.VOLUME_EXTERNAL
                } else {
                    MediaStore.VOLUME_EXTERNAL
                }

                val relativePath = if (relativePathColumn != -1 && !c.isNull(relativePathColumn)) {
                    c.getString(relativePathColumn)
                } else null

                val dateTaken = if (dateTakenColumn != -1 && !c.isNull(dateTakenColumn)) {
                    c.getLong(dateTakenColumn)
                } else null

                val width = if (widthColumn != -1 && !c.isNull(widthColumn)) {
                    c.getInt(widthColumn)
                } else null

                val height = if (heightColumn != -1 && !c.isNull(heightColumn)) {
                    c.getInt(heightColumn)
                } else null

                val contentUri = ContentUris.withAppendedId(collectionUri, id)

                items.add(
                    DiscoveredMediaItem(
                        mediaStoreId = id,
                        volumeName = volume,
                        contentUri = contentUri,
                        displayName = name,
                        relativePath = relativePath,
                        mimeType = mime,
                        sizeBytes = size,
                        dateTakenMs = dateTaken,
                        dateModifiedSec = dateModified,
                        width = width,
                        height = height,
                        mediaType = mediaType
                    )
                )
            }
        }

        return items
    }
}
