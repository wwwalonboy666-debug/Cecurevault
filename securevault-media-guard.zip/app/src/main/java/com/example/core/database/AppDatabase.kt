package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.core.database.converter.Converters
import com.example.core.database.dao.MediaSourceDao
import com.example.core.database.dao.ProtectedMediaDao
import com.example.core.database.dao.ProtectionLogDao
import com.example.core.database.dao.ProtectionTaskQueueDao
import com.example.core.database.entity.MediaSourceEntity
import com.example.core.database.entity.ProtectedMediaEntity
import com.example.core.database.entity.ProtectionLogEntity
import com.example.core.database.entity.ProtectionTaskEntity

/**
 * Main Room database for Media Protector metadata.
 * Real media files reside strictly in app-private storage, never inside this database.
 */
@Database(
    entities = [
        ProtectedMediaEntity::class,
        MediaSourceEntity::class,
        ProtectionTaskEntity::class,
        ProtectionLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun protectedMediaDao(): ProtectedMediaDao
    abstract fun mediaSourceDao(): MediaSourceDao
    abstract fun protectionLogDao(): ProtectionLogDao
    abstract fun protectionTaskQueueDao(): ProtectionTaskQueueDao

    companion object {
        const val DATABASE_NAME = "media_protector.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                DATABASE_NAME
            ).build()
        }

        fun createInMemory(context: Context): AppDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                AppDatabase::class.java
            ).allowMainThreadQueries().build()
        }
    }
}
