package com.example.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.core.database.entity.ProtectionLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtectionLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: ProtectionLogEntity): Long

    @Query("SELECT * FROM protection_logs WHERE mediaId = :mediaId ORDER BY timestamp DESC")
    fun observeLogsForMedia(mediaId: Long): Flow<List<ProtectionLogEntity>>

    @Query("SELECT * FROM protection_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentLogs(limit: Int): Flow<List<ProtectionLogEntity>>

    @Query("DELETE FROM protection_logs WHERE timestamp < :cutoffTimestamp")
    suspend fun deleteOldLogs(cutoffTimestamp: Long)
}
