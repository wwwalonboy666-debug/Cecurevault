package com.example.core.permission

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.domain.model.MediaPermissionState

/**
 * Utility for managing Android runtime media permissions across Android API levels:
 * - Android 14+ (API 34+): READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, READ_MEDIA_VISUAL_USER_SELECTED
 * - Android 13 (API 33): READ_MEDIA_IMAGES, READ_MEDIA_VIDEO
 * - Android 12 and below (API <= 32): READ_EXTERNAL_STORAGE
 */
object MediaPermissionManager {

    /**
     * Returns the list of runtime permissions needed by the current Android OS level.
     */
    fun getRequiredPermissions(): Array<String> {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> {
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                )
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
                )
            }
            else -> {
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )
            }
        }
    }

    /**
     * Checks current permission state on the device.
     */
    fun checkPermissionState(context: Context): MediaPermissionState {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> {
                val hasImages = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_IMAGES
                ) == PackageManager.PERMISSION_GRANTED
                val hasVideos = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED
                val hasUserSelected = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                ) == PackageManager.PERMISSION_GRANTED

                return when {
                    hasImages && hasVideos -> MediaPermissionState.Granted
                    hasImages || hasVideos -> MediaPermissionState.Granted
                    hasUserSelected -> MediaPermissionState.PartialGranted
                    else -> MediaPermissionState.NotRequested
                }
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                val hasImages = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_IMAGES
                ) == PackageManager.PERMISSION_GRANTED
                val hasVideos = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED

                return if (hasImages || hasVideos) {
                    MediaPermissionState.Granted
                } else {
                    MediaPermissionState.NotRequested
                }
            }
            else -> {
                val hasStorage = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED

                return if (hasStorage) {
                    MediaPermissionState.Granted
                } else {
                    MediaPermissionState.NotRequested
                }
            }
        }
    }

    /**
     * Translates a permission result map from RequestMultiplePermissions into a MediaPermissionState.
     */
    fun mapPermissionResult(
        permissions: Map<String, Boolean>
    ): MediaPermissionState {
        val hasImages = permissions[Manifest.permission.READ_MEDIA_IMAGES] == true
        val hasVideos = permissions[Manifest.permission.READ_MEDIA_VIDEO] == true
        val hasStorage = permissions[Manifest.permission.READ_EXTERNAL_STORAGE] == true
        val hasPartial = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            permissions[Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED] == true
        } else {
            false
        }

        return when {
            hasImages && hasVideos -> MediaPermissionState.Granted
            hasImages || hasVideos -> MediaPermissionState.Granted
            hasStorage -> MediaPermissionState.Granted
            hasPartial -> MediaPermissionState.PartialGranted
            else -> MediaPermissionState.Denied(shouldShowRationale = false)
        }
    }
}
