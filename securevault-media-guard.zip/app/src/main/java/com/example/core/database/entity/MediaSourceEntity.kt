package com.example.core.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a monitored media source:
 * Can be a MediaStore-based source (e.g., Camera, Screenshots)
 * or a user-selected Storage Access Framework (SAF) folder tree.
 */
@Entity(
    tableName = "media_sources",
    indices = [
        Index(value = ["folderUri"], unique = true)
    ]
)
data class MediaSourceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val folderName: String,
    val folderUri: String,
    val isSafTree: Boolean,
    val autoProtect: Boolean = true,
    val lastScanTimestamp: Long = 0L
)
