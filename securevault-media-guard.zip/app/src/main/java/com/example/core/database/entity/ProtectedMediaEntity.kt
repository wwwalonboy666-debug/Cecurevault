package com.example.core.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Metadata record for a protected photo or video.
 * Does NOT store media binaries; files reside in app-private storage.
 * Multi-factor identity prevents reliance on originalUri alone.
 */
@Entity(
    tableName = "protected_media",
    indices = [
        Index(value = ["originalMediaStoreId"]),
        Index(value = ["headerChecksum"]),
        Index(value = ["expiresAt"]),
        Index(value = ["originalStatus"]),
        Index(value = ["protectionState"])
    ]
)
data class ProtectedMediaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val originalMediaStoreId: Long? = null,
    val originalDocumentId: String? = null,
    val originalRelativePath: String? = null,
    val originalVolumeName: String? = null,
    val originalFileName: String,
    val vaultRelativePath: String,
    val mediaType: MediaType,
    val mimeType: String,
    val sizeBytes: Long,
    val headerChecksum: String,
    val fullSha256: String? = null,
    val dateTaken: Long,
    val dateModified: Long,
    val protectedAt: Long,
    val retentionDays: Int = RetentionPolicy.DEFAULT_RETENTION_DAYS,
    val expiresAt: Long = protectedAt + (retentionDays * RetentionPolicy.MILLIS_PER_DAY),
    val originalStatus: OriginalStatus = OriginalStatus.ACCESSIBLE,
    val protectionState: ProtectionState = ProtectionState.QUEUED,
    val verificationState: VerificationState = VerificationState.PENDING_CHECK,
    val isEncrypted: Boolean = false
) {
    init {
        RetentionPolicy.validate(retentionDays)
    }
}
