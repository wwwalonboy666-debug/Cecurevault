package com.example.core.database.entity

/**
 * Retention policy options strictly locked for V1:
 * Only 30, 90 (default), or 180 days are allowed.
 */
object RetentionPolicy {
    const val RETENTION_30_DAYS = 30
    const val RETENTION_90_DAYS = 90
    const val RETENTION_180_DAYS = 180
    const val DEFAULT_RETENTION_DAYS = RETENTION_90_DAYS

    val ALLOWED_RETENTION_DAYS: Set<Int> = setOf(
        RETENTION_30_DAYS,
        RETENTION_90_DAYS,
        RETENTION_180_DAYS
    )

    fun isValid(days: Int): Boolean = days in ALLOWED_RETENTION_DAYS

    fun validate(days: Int): Int {
        require(isValid(days)) {
            "Invalid retention period: $days days. V1 strictly allows only 30, 90, or 180 days."
        }
        return days
    }

    const val MILLIS_PER_DAY = 86_400_000L

    fun calculateExpiresAt(protectedAt: Long, retentionDays: Int): Long {
        validate(retentionDays)
        return protectedAt + (retentionDays * MILLIS_PER_DAY)
    }
}
