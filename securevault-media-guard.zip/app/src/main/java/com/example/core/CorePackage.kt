package com.example.core

/**
 * Core foundation package for Media Protector.
 * Houses database, storage, media queries, security, and notifications.
 */
object CorePackage
