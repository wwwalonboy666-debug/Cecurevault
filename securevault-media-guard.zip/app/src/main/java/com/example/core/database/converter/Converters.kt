package com.example.core.database.converter

import androidx.room.TypeConverter
import com.example.core.database.entity.LogEventType
import com.example.core.database.entity.MediaType
import com.example.core.database.entity.OriginalStatus
import com.example.core.database.entity.ProtectionState
import com.example.core.database.entity.TaskState
import com.example.core.database.entity.VerificationState

/**
 * Deterministic and safe Room type converters for database enums.
 */
class Converters {

    @TypeConverter
    fun fromMediaType(value: MediaType?): String? = value?.name

    @TypeConverter
    fun toMediaType(value: String?): MediaType? = value?.let {
        runCatching { MediaType.valueOf(it) }.getOrDefault(MediaType.PHOTO)
    }

    @TypeConverter
    fun fromOriginalStatus(value: OriginalStatus?): String? = value?.name

    @TypeConverter
    fun toOriginalStatus(value: String?): OriginalStatus? = value?.let {
        runCatching { OriginalStatus.valueOf(it) }.getOrDefault(OriginalStatus.ACCESSIBLE)
    }

    @TypeConverter
    fun fromProtectionState(value: ProtectionState?): String? = value?.name

    @TypeConverter
    fun toProtectionState(value: String?): ProtectionState? = value?.let {
        runCatching { ProtectionState.valueOf(it) }.getOrDefault(ProtectionState.QUEUED)
    }

    @TypeConverter
    fun fromVerificationState(value: VerificationState?): String? = value?.name

    @TypeConverter
    fun toVerificationState(value: String?): VerificationState? = value?.let {
        runCatching { VerificationState.valueOf(it) }.getOrDefault(VerificationState.PENDING_CHECK)
    }

    @TypeConverter
    fun fromTaskState(value: TaskState?): String? = value?.name

    @TypeConverter
    fun toTaskState(value: String?): TaskState? = value?.let {
        runCatching { TaskState.valueOf(it) }.getOrDefault(TaskState.PENDING)
    }

    @TypeConverter
    fun fromLogEventType(value: LogEventType?): String? = value?.name

    @TypeConverter
    fun toLogEventType(value: String?): LogEventType? = value?.let {
        runCatching { LogEventType.valueOf(it) }.getOrDefault(LogEventType.PROTECTED)
    }
}
