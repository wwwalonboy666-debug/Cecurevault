package com.example.core.database.entity

enum class MediaType {
    PHOTO,
    VIDEO
}

enum class OriginalStatus {
    ACCESSIBLE,
    POTENTIALLY_MOVED,
    MISSING,
    RESTORED
}

enum class ProtectionState {
    QUEUED,
    COPYING_TEMP,
    VERIFYING,
    PROTECTED,
    FAILED_RETRYABLE,
    FAILED_PERMANENT
}

enum class VerificationState {
    VERIFIED,
    PENDING_CHECK,
    CORRUPTED
}

enum class TaskState {
    PENDING,
    RUNNING,
    FAILED_RETRYABLE,
    FAILED_PERMANENT,
    COMPLETED
}

enum class LogEventType {
    PROTECTED,
    VERIFIED,
    RESTORED,
    CLEANED_EXPIRED,
    INTEGRITY_FAILED,
    ORIGINAL_MISSING
}
