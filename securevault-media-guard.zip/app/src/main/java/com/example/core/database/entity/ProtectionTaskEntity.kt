package com.example.core.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Tracks scheduled or queued protection tasks for retry handling with backoff.
 */
@Entity(
    tableName = "protection_tasks",
    indices = [
        Index(value = ["taskState"]),
        Index(value = ["nextRetryAt"])
    ]
)
data class ProtectionTaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mediaUri: String,
    val attemptCount: Int = 0,
    val maxRetries: Int = 3,
    val lastError: String? = null,
    val nextRetryAt: Long = 0L,
    val taskState: TaskState = TaskState.PENDING
)
