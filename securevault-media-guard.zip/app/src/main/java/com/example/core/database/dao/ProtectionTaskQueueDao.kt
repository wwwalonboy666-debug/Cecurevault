package com.example.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.database.entity.ProtectionTaskEntity
import com.example.core.database.entity.TaskState
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtectionTaskQueueDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: ProtectionTaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<ProtectionTaskEntity>): List<Long>

    @Update
    suspend fun update(task: ProtectionTaskEntity)

    @Delete
    suspend fun delete(task: ProtectionTaskEntity)

    @Query("DELETE FROM protection_tasks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM protection_tasks WHERE id = :id")
    suspend fun getById(id: Long): ProtectionTaskEntity?

    @Query("SELECT * FROM protection_tasks WHERE taskState = 'PENDING' OR (taskState = 'FAILED_RETRYABLE' AND nextRetryAt <= :currentTime) ORDER BY id ASC")
    suspend fun getRunnableTasks(currentTime: Long): List<ProtectionTaskEntity>

    @Query("SELECT COUNT(*) FROM protection_tasks WHERE taskState = 'PENDING' OR taskState = 'RUNNING'")
    fun observePendingCount(): Flow<Int>

    @Query("DELETE FROM protection_tasks WHERE taskState = 'COMPLETED'")
    suspend fun clearCompleted()
}
