package com.example.core.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Audit log of protection events.
 * Does not store sensitive binaries or user personal information.
 */
@Entity(
    tableName = "protection_logs",
    indices = [
        Index(value = ["mediaId"]),
        Index(value = ["timestamp"])
    ]
)
data class ProtectionLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mediaId: Long? = null,
    val eventType: LogEventType,
    val timestamp: Long,
    val details: String
)
