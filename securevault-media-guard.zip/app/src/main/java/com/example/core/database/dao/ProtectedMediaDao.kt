package com.example.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.database.entity.OriginalStatus
import com.example.core.database.entity.ProtectedMediaEntity
import com.example.core.database.entity.ProtectionState
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtectedMediaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ProtectedMediaEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<ProtectedMediaEntity>): List<Long>

    @Update
    suspend fun update(entity: ProtectedMediaEntity)

    @Delete
    suspend fun delete(entity: ProtectedMediaEntity)

    @Query("DELETE FROM protected_media WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM protected_media WHERE id = :id")
    suspend fun getById(id: Long): ProtectedMediaEntity?

    @Query("SELECT * FROM protected_media ORDER BY protectedAt DESC")
    fun observeAll(): Flow<List<ProtectedMediaEntity>>

    @Query("SELECT * FROM protected_media WHERE originalMediaStoreId = :mediaStoreId LIMIT 1")
    suspend fun getByOriginalMediaStoreId(mediaStoreId: Long): ProtectedMediaEntity?

    @Query("SELECT * FROM protected_media WHERE originalDocumentId = :documentId LIMIT 1")
    suspend fun getByOriginalDocumentId(documentId: String): ProtectedMediaEntity?

    @Query("SELECT * FROM protected_media WHERE headerChecksum = :checksum")
    suspend fun getByHeaderChecksum(checksum: String): List<ProtectedMediaEntity>

    @Query("SELECT * FROM protected_media WHERE originalStatus = :status ORDER BY protectedAt DESC")
    fun observeByOriginalStatus(status: OriginalStatus): Flow<List<ProtectedMediaEntity>>

    @Query("SELECT * FROM protected_media WHERE originalStatus = :status")
    suspend fun getByOriginalStatusList(status: OriginalStatus): List<ProtectedMediaEntity>

    @Query("SELECT * FROM protected_media WHERE expiresAt <= :currentTimestamp AND protectionState = 'PROTECTED'")
    suspend fun getExpired(currentTimestamp: Long): List<ProtectedMediaEntity>

    @Query("SELECT * FROM protected_media WHERE expiresAt > :currentTimestamp AND expiresAt <= :thresholdTimestamp AND protectionState = 'PROTECTED'")
    suspend fun getExpiringSoon(thresholdTimestamp: Long, currentTimestamp: Long): List<ProtectedMediaEntity>

    @Query("SELECT COUNT(*) FROM protected_media WHERE protectionState = 'PROTECTED'")
    fun observeProtectedCount(): Flow<Int>

    @Query("SELECT SUM(sizeBytes) FROM protected_media WHERE protectionState = 'PROTECTED'")
    fun observeTotalProtectedBytes(): Flow<Long?>
}
