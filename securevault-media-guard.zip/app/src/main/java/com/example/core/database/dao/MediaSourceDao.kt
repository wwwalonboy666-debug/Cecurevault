package com.example.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.database.entity.MediaSourceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaSourceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(source: MediaSourceEntity): Long

    @Update
    suspend fun update(source: MediaSourceEntity)

    @Delete
    suspend fun delete(source: MediaSourceEntity)

    @Query("DELETE FROM media_sources WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM media_sources WHERE id = :id")
    suspend fun getById(id: Long): MediaSourceEntity?

    @Query("SELECT * FROM media_sources WHERE folderUri = :uri LIMIT 1")
    suspend fun getByUri(uri: String): MediaSourceEntity?

    @Query("SELECT * FROM media_sources ORDER BY folderName ASC")
    fun observeAll(): Flow<List<MediaSourceEntity>>

    @Query("SELECT * FROM media_sources WHERE autoProtect = 1")
    suspend fun getAutoProtectSources(): List<MediaSourceEntity>
}
