package com.example.domain.repository

import com.example.domain.model.DiscoveredMediaItem
import com.example.domain.model.MediaDiscoverySummary
import kotlinx.coroutines.flow.Flow

/**
 * Interface for reading media items directly from Android MediaStore.
 * Strictly local, metadata-only read operations.
 */
interface MediaStoreDiscoveryRepository {
    /**
     * Query all photos and videos available from device MediaStore.
     */
    suspend fun queryDiscoveredMedia(): List<DiscoveredMediaItem>

    /**
     * Get aggregate count summary of discovered photos and videos.
     */
    suspend fun getDiscoverySummary(): MediaDiscoverySummary
}
