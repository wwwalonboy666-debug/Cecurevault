package com.example.domain.model

import android.net.Uri

/**
 * Type of media detected from Android MediaStore.
 */
enum class DetectedMediaType {
    PHOTO,
    VIDEO
}

/**
 * Local media item discovered via Android MediaStore.
 * Collects only metadata needed for subsequent stages without loading full file bytes or calculating hashes.
 */
data class DiscoveredMediaItem(
    val mediaStoreId: Long,
    val volumeName: String,
    val contentUri: Uri,
    val displayName: String,
    val relativePath: String?,
    val mimeType: String,
    val sizeBytes: Long,
    val dateTakenMs: Long?,
    val dateModifiedSec: Long,
    val width: Int?,
    val height: Int?,
    val mediaType: DetectedMediaType
)

/**
 * Summary count and metrics of media discovered on the device.
 */
data class MediaDiscoverySummary(
    val photoCount: Int = 0,
    val videoCount: Int = 0,
    val totalSizeBytes: Long = 0L,
    val recentItems: List<DiscoveredMediaItem> = emptyList()
) {
    val totalCount: Int get() = photoCount + videoCount
}
