package com.example.domain

/**
 * Domain layer package for Media Protector.
 * Houses models, use cases, repository interfaces, and engines.
 */
object DomainPackage
