package com.example.domain.model

/**
 * State of local media access permission.
 */
sealed interface MediaPermissionState {
    /**
     * Initial state before user has been prompted for permission.
     */
    data object NotRequested : MediaPermissionState

    /**
     * Permission granted to access all photos and videos on the device.
     */
    data object Granted : MediaPermissionState

    /**
     * Android 14+ (API 34+) partial access where user selected specific photos/videos.
     */
    data object PartialGranted : MediaPermissionState

    /**
     * Permission was denied by the user.
     * @param shouldShowRationale true if standard permission rationale should be displayed
     */
    data class Denied(val shouldShowRationale: Boolean) : MediaPermissionState

    /**
     * Permission was permanently denied (e.g. "Don't ask again") requiring App Settings.
     */
    data object PermanentlyDenied : MediaPermissionState
}
