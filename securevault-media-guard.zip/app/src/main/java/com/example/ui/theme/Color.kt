package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme - Nature × Safety × Peace
val PinePrimaryLight = Color(0xFF1E4D3E)       // Deep calm forest pine
val PineOnPrimaryLight = Color(0xFFFFFFFF)
val PinePrimaryContainerLight = Color(0xFFD4E8DD)
val PineOnPrimaryContainerLight = Color(0xFF072018)

val SageSecondaryLight = Color(0xFF4C6358)     // Soft earthy sage
val SageOnSecondaryLight = Color(0xFFFFFFFF)
val SageSecondaryContainerLight = Color(0xFFCEE9DA)
val SageOnSecondaryContainerLight = Color(0xFF092017)

val EarthTertiaryLight = Color(0xFF3F6375)     // Gentle serene river slate
val EarthOnTertiaryLight = Color(0xFFFFFFFF)
val EarthTertiaryContainerLight = Color(0xFFC3E8FD)
val EarthOnTertiaryContainerLight = Color(0xFF001F2A)

val CalmBackgroundLight = Color(0xFFF7FBF7)    // Soft peaceful canvas
val CalmOnBackgroundLight = Color(0xFF181D1A)
val CalmSurfaceLight = Color(0xFFF7FBF7)
val CalmOnSurfaceLight = Color(0xFF181D1A)
val CalmSurfaceVariantLight = Color(0xFFDCE5DF)
val CalmOnSurfaceVariantLight = Color(0xFF404944)

// Dark Theme - Nature × Safety × Peace
val PinePrimaryDark = Color(0xFF86D5B5)        // Luminous calm sage emerald
val PineOnPrimaryDark = Color(0xFF003828)
val PinePrimaryContainerDark = Color(0xFF00513B)
val PineOnPrimaryContainerDark = Color(0xFFA2F2D0)

val SageSecondaryDark = Color(0xFFB3CCBF)
val SageOnSecondaryDark = Color(0xFF1E352B)
val SageSecondaryContainerDark = Color(0xFF354C41)
val SageOnSecondaryContainerDark = Color(0xFFCEE9DA)

val EarthTertiaryDark = Color(0xFFA7CBE0)
val EarthOnTertiaryDark = Color(0xFF093545)
val EarthTertiaryContainerDark = Color(0xFF264C5D)
val EarthOnTertiaryContainerDark = Color(0xFFC3E8FD)

val CalmBackgroundDark = Color(0xFF101513)     // Deep peaceful dark
val CalmOnBackgroundDark = Color(0xFFE0E3DF)
val CalmSurfaceDark = Color(0xFF101513)
val CalmOnSurfaceDark = Color(0xFFE0E3DF)
val CalmSurfaceVariantDark = Color(0xFF404944)
val CalmOnSurfaceVariantDark = Color(0xFFBFC9C3)
