package com.example.ui.home

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.permission.MediaPermissionManager
import com.example.data.repository.MediaStoreDiscoveryRepositoryImpl
import com.example.domain.model.MediaDiscoverySummary
import com.example.domain.model.MediaPermissionState
import com.example.domain.repository.MediaStoreDiscoveryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * UI State representing permission, scan state, and discovered media metrics.
 */
data class HomeUiState(
    val permissionState: MediaPermissionState = MediaPermissionState.NotRequested,
    val isScanning: Boolean = false,
    val discoverySummary: MediaDiscoverySummary = MediaDiscoverySummary(),
    val protectedPhotosCount: Int = 0,
    val protectedVideosCount: Int = 0,
    val recoveryItemsCount: Int = 0,
    val vaultStorageDisplay: String = "০ বি",
    val hasScannedOnce: Boolean = false
) {
    val hasDiscoveredMedia: Boolean get() = discoverySummary.totalCount > 0
}

/**
 * ViewModel orchestrating permission tracking and MediaStore detection cleanly outside Composables.
 */
class HomeViewModel(
    application: Application,
    private val discoveryRepository: MediaStoreDiscoveryRepository = MediaStoreDiscoveryRepositoryImpl(application)
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        checkInitialPermission()
    }

    /**
     * Checks current permission status upon launch.
     */
    fun checkInitialPermission() {
        val context = getApplication<Application>()
        val state = MediaPermissionManager.checkPermissionState(context)
        _uiState.update { it.copy(permissionState = state) }

        if (state is MediaPermissionState.Granted || state is MediaPermissionState.PartialGranted) {
            scanDiscoveredMedia()
        }
    }

    /**
     * Handles result callback from Compose rememberLauncherForActivityResult.
     */
    fun onPermissionResult(permissions: Map<String, Boolean>) {
        val resultState = MediaPermissionManager.mapPermissionResult(permissions)
        _uiState.update { it.copy(permissionState = resultState) }

        if (resultState is MediaPermissionState.Granted || resultState is MediaPermissionState.PartialGranted) {
            scanDiscoveredMedia()
        }
    }

    /**
     * Manually triggers MediaStore detection query.
     */
    fun scanDiscoveredMedia() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true) }
            try {
                val summary = discoveryRepository.getDiscoverySummary()
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        discoverySummary = summary,
                        hasScannedOnce = true
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        hasScannedOnce = true
                    )
                }
            }
        }
    }

    /**
     * Opens system app settings screen when permission is denied or restricted.
     */
    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
