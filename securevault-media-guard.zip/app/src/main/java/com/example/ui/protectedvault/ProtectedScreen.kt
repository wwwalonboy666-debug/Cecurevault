package com.example.ui.protectedvault

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R

/**
 * Visual filter categories for Protected Media Screen
 */
enum class ProtectedFilter {
    ALL,
    PHOTOS,
    VIDEOS
}

/**
 * Preview UI model for Protected Media Cards
 */
data class SampleMediaItem(
    val id: String,
    val title: String,
    val isVideo: Boolean,
    val dateText: String,
    val sourceText: String,
    val gradientColors: List<Color>
)

/**
 * UI State representation for Protected Screen
 */
enum class ProtectedUiState {
    CONTENT,
    EMPTY,
    LOADING,
    ERROR
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProtectedScreen(
    modifier: Modifier = Modifier,
    initialState: ProtectedUiState = ProtectedUiState.CONTENT
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(ProtectedFilter.ALL) }
    var sortDateAscending by remember { mutableStateOf(false) }
    var sourceDropdownOpen by remember { mutableStateOf(false) }
    var currentUiState by remember { mutableStateOf(initialState) }

    // Curated UI-only sample media items adhering to Nature x Safety palette
    val sampleItems = remember {
        listOf(
            SampleMediaItem(
                id = "item_1",
                title = "IMG_2026_0901.jpg",
                isVideo = false,
                dateText = "১০ সেপ্টেম্বর",
                sourceText = "Camera",
                gradientColors = listOf(Color(0xFF1B5E3A), Color(0xFF3C6451))
            ),
            SampleMediaItem(
                id = "item_2",
                title = "VID_2026_0828.mp4",
                isVideo = true,
                dateText = "৮ সেপ্টেম্বর",
                sourceText = "WhatsApp",
                gradientColors = listOf(Color(0xFF2C4A3E), Color(0xFF153327))
            ),
            SampleMediaItem(
                id = "item_3",
                title = "IMG_2026_0814.jpg",
                isVideo = false,
                dateText = "৫ সেপ্টেম্বর",
                sourceText = "Screenshots",
                gradientColors = listOf(Color(0xFF234F3C), Color(0xFF436B57))
            ),
            SampleMediaItem(
                id = "item_4",
                title = "VID_2026_0802.mp4",
                isVideo = true,
                dateText = "২ সেপ্টেম্বর",
                sourceText = "Camera",
                gradientColors = listOf(Color(0xFF1E3A2B), Color(0xFF385747))
            ),
            SampleMediaItem(
                id = "item_5",
                title = "IMG_2026_0729.jpg",
                isVideo = false,
                dateText = "২৯ আগস্ট",
                sourceText = "Custom",
                gradientColors = listOf(Color(0xFF2E5E43), Color(0xFF568069))
            ),
            SampleMediaItem(
                id = "item_6",
                title = "IMG_2026_0720.jpg",
                isVideo = false,
                dateText = "২০ আগস্ট",
                sourceText = "Camera",
                gradientColors = listOf(Color(0xFF18422A), Color(0xFF345A42))
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("protected_screen_root")
    ) {
        // 1. Top App Bar
        TopAppBar(
            title = {
                Text(
                    text = stringResource(R.string.protected_screen_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            actions = {
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .testTag("protected_top_status_badge"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = stringResource(R.string.badge_protected),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            modifier = Modifier.testTag("protected_top_app_bar")
        )

        when (currentUiState) {
            ProtectedUiState.LOADING -> {
                ProtectedLoadingState()
            }
            ProtectedUiState.ERROR -> {
                ProtectedErrorState(onRetry = { currentUiState = ProtectedUiState.CONTENT })
            }
            ProtectedUiState.EMPTY -> {
                ProtectedEmptyState()
            }
            ProtectedUiState.CONTENT -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("protected_media_grid"),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 2. Summary Section
                    item(span = { GridItemSpan(2) }) {
                        ProtectedSummaryHeader()
                    }

                    // 3. Search Field
                    item(span = { GridItemSpan(2) }) {
                        ProtectedSearchBar(
                            query = searchQuery,
                            onQueryChange = { searchQuery = it }
                        )
                    }

                    // 4. Filter & Sort Chips Row
                    item(span = { GridItemSpan(2) }) {
                        ProtectedFilterRow(
                            selectedFilter = selectedFilter,
                            onFilterSelect = { selectedFilter = it },
                            sortDateAscending = sortDateAscending,
                            onToggleDateSort = { sortDateAscending = !sortDateAscending }
                        )
                    }

                    // 5. Responsive 2-column Media Cards
                    val displayedItems = sampleItems.filter { item ->
                        when (selectedFilter) {
                            ProtectedFilter.ALL -> true
                            ProtectedFilter.PHOTOS -> !item.isVideo
                            ProtectedFilter.VIDEOS -> item.isVideo
                        }
                    }.filter { item ->
                        searchQuery.isEmpty() || item.title.contains(searchQuery, ignoreCase = true)
                    }

                    if (displayedItems.isEmpty()) {
                        item(span = { GridItemSpan(2) }) {
                            ProtectedEmptyState()
                        }
                    } else {
                        items(displayedItems, key = { it.id }) { mediaItem ->
                            ProtectedMediaCard(
                                item = mediaItem,
                                onClick = { /* Visual press feedback */ }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. Summary Section Card
 */
@Composable
private fun ProtectedSummaryHeader(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("protected_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.protected_summary_count),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stringResource(R.string.protected_summary_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}

/**
 * 3. Search Bar
 */
@Composable
private fun ProtectedSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier
            .fillMaxWidth()
            .testTag("protected_search_field"),
        placeholder = {
            Text(
                text = stringResource(R.string.search_media_placeholder),
                style = MaterialTheme.typography.bodyMedium
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = stringResource(R.string.search_icon_cd),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(
                    onClick = { onQueryChange("") },
                    modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = stringResource(R.string.clear_search_cd),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(100.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
        )
    )
}

/**
 * 4. Filter & Sort Controls
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProtectedFilterRow(
    selectedFilter: ProtectedFilter,
    onFilterSelect: (ProtectedFilter) -> Unit,
    sortDateAscending: Boolean,
    onToggleDateSort: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .testTag("protected_filter_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilterChip(
            selected = selectedFilter == ProtectedFilter.ALL,
            onClick = { onFilterSelect(ProtectedFilter.ALL) },
            label = { Text(stringResource(R.string.filter_all)) },
            leadingIcon = if (selectedFilter == ProtectedFilter.ALL) {
                {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            } else null,
            shape = RoundedCornerShape(100.dp),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("filter_chip_all")
        )

        FilterChip(
            selected = selectedFilter == ProtectedFilter.PHOTOS,
            onClick = { onFilterSelect(ProtectedFilter.PHOTOS) },
            label = { Text(stringResource(R.string.filter_photos)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            },
            shape = RoundedCornerShape(100.dp),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("filter_chip_photos")
        )

        FilterChip(
            selected = selectedFilter == ProtectedFilter.VIDEOS,
            onClick = { onFilterSelect(ProtectedFilter.VIDEOS) },
            label = { Text(stringResource(R.string.filter_videos)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            },
            shape = RoundedCornerShape(100.dp),
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("filter_chip_videos")
        )

        FilterChip(
            selected = false,
            onClick = onToggleDateSort,
            label = { Text(stringResource(R.string.filter_date)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            },
            shape = RoundedCornerShape(100.dp),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("filter_chip_date")
        )

        FilterChip(
            selected = false,
            onClick = { /* Toggle source filter state */ },
            label = { Text(stringResource(R.string.filter_source)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            },
            trailingIcon = {
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            },
            shape = RoundedCornerShape(100.dp),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("filter_chip_source")
        )
    }
}

/**
 * 5. Media Card (2-Column Grid Item)
 */
@Composable
private fun ProtectedMediaCard(
    item: SampleMediaItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("protected_card_${item.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Thumbnail Area with Gradient Canvas + Shield Badge + Video Play Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(
                        Brush.linearGradient(colors = item.gradientColors)
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Media Type Ambient Icon
                Icon(
                    imageVector = if (item.isVideo) Icons.Default.Videocam else Icons.Default.Image,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier.size(48.dp)
                )

                // Video Center Play Icon
                if (item.isVideo) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .testTag("video_play_overlay_${item.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = stringResource(R.string.video_play_cd),
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // Top-right Protected Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(100.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = stringResource(R.string.badge_protected),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Metadata Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.dateText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Text(
                        text = item.sourceText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

/**
 * 7. Empty State Composable
 */
@Composable
fun ProtectedEmptyState(
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("protected_empty_state_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = stringResource(R.string.protected_empty_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.protected_empty_description),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }
    }
}

/**
 * 8. Loading State Composable
 */
@Composable
fun ProtectedLoadingState(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp)
            .testTag("protected_loading_state"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(48.dp),
            color = MaterialTheme.colorScheme.primary,
            strokeWidth = 4.dp
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = stringResource(R.string.protected_loading_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = stringResource(R.string.protected_loading_description),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * 8. Error State Composable
 */
@Composable
fun ProtectedErrorState(
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp)
            .testTag("protected_error_state"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.errorContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = stringResource(R.string.protected_error_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = stringResource(R.string.protected_error_description),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onRetry,
            shape = RoundedCornerShape(100.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .testTag("protected_retry_button")
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.action_retry),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
