package com.example.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R

sealed class Screen(
    val route: String,
    @get:StringRes val titleRes: Int,
    val icon: ImageVector,
    val testTag: String
) {
    object Home : Screen(
        route = "home",
        titleRes = R.string.nav_home,
        icon = Icons.Outlined.Home,
        testTag = "nav_tab_home"
    )

    object Protected : Screen(
        route = "protected",
        titleRes = R.string.nav_protected,
        icon = Icons.Outlined.FolderSpecial,
        testTag = "nav_tab_protected"
    )

    object Recovery : Screen(
        route = "recovery",
        titleRes = R.string.nav_recovery,
        icon = Icons.Outlined.Restore,
        testTag = "nav_tab_recovery"
    )

    object Settings : Screen(
        route = "settings",
        titleRes = R.string.nav_settings,
        icon = Icons.Outlined.Settings,
        testTag = "nav_tab_settings"
    )
}
