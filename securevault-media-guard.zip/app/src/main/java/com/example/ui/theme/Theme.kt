package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = PinePrimaryDark,
    onPrimary = PineOnPrimaryDark,
    primaryContainer = PinePrimaryContainerDark,
    onPrimaryContainer = PineOnPrimaryContainerDark,
    secondary = SageSecondaryDark,
    onSecondary = SageOnSecondaryDark,
    secondaryContainer = SageSecondaryContainerDark,
    onSecondaryContainer = SageOnSecondaryContainerDark,
    tertiary = EarthTertiaryDark,
    onTertiary = EarthOnTertiaryDark,
    tertiaryContainer = EarthTertiaryContainerDark,
    onTertiaryContainer = EarthOnTertiaryContainerDark,
    background = CalmBackgroundDark,
    onBackground = CalmOnBackgroundDark,
    surface = CalmSurfaceDark,
    onSurface = CalmOnSurfaceDark,
    surfaceVariant = CalmSurfaceVariantDark,
    onSurfaceVariant = CalmOnSurfaceVariantDark,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PinePrimaryLight,
    onPrimary = PineOnPrimaryLight,
    primaryContainer = PinePrimaryContainerLight,
    onPrimaryContainer = PineOnPrimaryContainerLight,
    secondary = SageSecondaryLight,
    onSecondary = SageOnSecondaryLight,
    secondaryContainer = SageSecondaryContainerLight,
    onSecondaryContainer = SageOnSecondaryContainerLight,
    tertiary = EarthTertiaryLight,
    onTertiary = EarthOnTertiaryLight,
    tertiaryContainer = EarthTertiaryContainerLight,
    onTertiaryContainer = EarthOnTertiaryContainerLight,
    background = CalmBackgroundLight,
    onBackground = CalmOnBackgroundLight,
    surface = CalmSurfaceLight,
    onSurface = CalmOnSurfaceLight,
    surfaceVariant = CalmSurfaceVariantLight,
    onSurfaceVariant = CalmOnSurfaceVariantLight,
  )

@Composable
fun MediaProtectorTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep Nature x Safety x Peace theme consistent by default
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

// Alias for existing previews and backward compatibility
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MediaProtectorTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
